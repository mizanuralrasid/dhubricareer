<?php
require 'config.php';
session_start();
if (!isset($_SESSION['mobile']) || $_SESSION['loggedin'] !== true) {
    // header("Location: registration.php");
    // exit();
}


if (isset($_POST['register'])) {
    $id = $_GET['id'];
}
?>
<style>
    #profile {
        height: 35px;
        width: 35px;
        background: gray;
        border-radius: 50%;
        border: 2px solid black;
        position: absolute;
    }
</style>
<nav class="navbar bg-body-tertiary">
    <div class="container-fluid">
        <a class="navbar-brand">Navbar</a>
        <form class="d-flex" role="search">
            <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
            <button class="btn btn-outline-success" type="submit">Search</button>
        </form>
    </div>
</nav>
<nav class="navbar navbar-expand-lg bg-body-tertiary">
    <div class="container-fluid">
        <!-- <a class="navbar-brand" href="#">Navbar</a> -->
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavDropdown">
            <ul class="navbar-nav">
                <li class="nav-item mx-5">
                    <a class="nav-link active" aria-current="page" href="#">Home</a>
                </li>
                <li class="nav-item mx-5">
                    <a class="nav-link" href="about.php">About Us</a>
                </li>
                <li class="nav-item mx-5">
                    <a class="nav-link" href="contact.php">Contact Us</a>
                </li>
                <li class="nav-item mx-5">
                    <a class="nav-link" href="#">Features</a>
                </li>
                <li class="nav-item mx-5">
                    <a class="nav-link" href="#">Services</a>
                </li>
                <li class="nav-item mx-5 dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        Dropdown link
                    </a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="#">Action</a></li>
                        <li><a class="dropdown-item" href="#">Another action</a></li>
                        <li><a class="dropdown-item" href="#">Something else here</a></li>
                    </ul>
                </li>
                <?php
                if (isset($_SESSION['mobile'])) {
                ?>

                    <li class="nav-item mx-5 dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false" id="profile">
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item"><?php echo  $_SESSION['mobile']; ?></a></li>
                            <li><a class="dropdown-item" href="#">profile</a></li>
                            <li><a class="dropdown-item" href="./logout.php">logout</a></li>
                        </ul>
                    </li>
                <?php
                }
                ?>
            </ul>
        </div>
    </div>
</nav>