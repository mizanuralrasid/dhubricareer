<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link rel="stylesheet" href="style.css">
    <?php
    include 'css/contact.php';
    ?>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">



    <style>
        body {
            width: auto;
        }

        /* .card {
      height: 60vh !important;
    }

    .card-body {
      height: 70% !important;
      overflow: hidden !important;
      text-overflow: ellipsis;
    }

    .card-body p {
      height: 48% !important;
      overflow: hidden !important;
      text-overflow: ellipsis;
    }

    .card-img-top {
      height: 50% !important;
    } */


        /* Extra small devices (portrait phones, less than 576px) */
        @media (max-width: 575.98px) {
            .card-group {
                display: block !important;
                grid-template-columns: auto auto !important;
            }

            .card-img-top {
                height: 30vh !important;
            }
        }

        /* Small devices (landscape phones, less than 768px) */
        @media (max-width: 767.98px) {}

        /* Medium devices (tablets, less than 992px) */
        @media (max-width: 991.98px) {
            .card-group {
                grid-template-columns: auto auto !important;
            }

        }

        /* Large devices (desktops, less than 1200px) */
        @media (max-width: 1199.98px) {}

        /* Extra large devices (large desktops) */
        /* No media query since the extra-large breakpoint has no upper bound on its width */
    </style>
</head>

<body>
    <?php
    include 'header.php';
    ?>






    <div class="container">
        <h1>Contact Us</h1>
        <form>
            <label for="name">Name</label>
            <input type="text" id="name" name="name" placeholder="Your name">

            <label for="email">Email</label>
            <input type="email" id="email" name="email" placeholder="Your email">

            <label for="message">Message</label>
            <textarea id="message" name="message" placeholder="Write your message here"></textarea>

            <input type="submit" value="Submit">
        </form>
    </div>



    <!-- ---------------------------------contact------------------------------------- -->



    <?php
    include 'footer.php';
    ?>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
</body>

</html>