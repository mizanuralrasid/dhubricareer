<?php
include '../config.php';
session_start();
if (!isset($_SESSION['username']) || $_SESSION['loggedin'] !== true) {
    header("Location: index.php");
    exit();
}

if (isset($_POST['update_applicants'])) {
    $id = $_GET['id'];
    $first_name = $conn->real_escape_string($_POST['first_name']);
    $last_name = $conn->real_escape_string($_POST['last_name']);
    $address = $conn->real_escape_string($_POST['address']);
    $city = $conn->real_escape_string($_POST['city']);
    $state = $conn->real_escape_string($_POST['state']);
    $zip = $conn->real_escape_string($_POST['zip']);
    $country = $conn->real_escape_string($_POST['country']);
    $email = $conn->real_escape_string($_POST['email']);
    $phone = $conn->real_escape_string($_POST['phone']);
    $position = $conn->real_escape_string($_POST['position']);

    $iq = "update applicants set id=$id,firstname='$first_name',lastname='$last_name',address='$address',city='$city',state='$state',zip='$zip',country='$country',email='$email',phone='$phone',position='$position' where id=$id";

    $q = $conn->query($iq);
    header('location: Dashboard.php');
} else {
    echo "somthing went wrong !";
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">

    <title>Dashboard - Dhubri Career </title>
    <meta content="" name="description">
    <meta content="" name="keywords">

    <!-- Favicons -->
    <link href="assets/img/favicon.png" rel="icon">
    <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

    <!-- Google Fonts -->
    <link href="https://fonts.gstatic.com" rel="preconnect">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

    <!-- Vendor CSS Files -->
    <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
    <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
    <link href="assets/vendor/quill/quill.snow.css" rel="stylesheet">
    <link href="assets/vendor/quill/quill.bubble.css" rel="stylesheet">
    <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
    <link href="assets/vendor/simple-datatables/style.css" rel="stylesheet">

    <!-- Template Main CSS File -->
    <link href="assets/css/style.css" rel="stylesheet">
</head>

<body>
    <!-- ======= Header ======= -->
    <?php
    include 'header.php';
    ?>
    <!-- End Header -->
    <!-- ======= Sidebar ======= -->
    <?php
    include 'sidebar.php';
    ?>
    <!-- End Sidebar-->
    <main id="main" class="main">
        <div class="pagetitle">
            <h1>Dashboard</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                    <li class="breadcrumb-item active">Dashboard</li>
                </ol>
            </nav>
        </div><!-- End Page Title -->
        <?php
        // session_start();
        include '../pages/message.php';
        ?>
        <section class="section dashboard">
            <div class="row">
                <!-- Left side columns -->
                <div class="col-sm-12">
                    <div class="row">
                        <!-- Recent Sales -->
                        <div class="col-12">
                            <div class="container mt-5">
                                <h3 class="fw-bolder mx-5 mb-3">Update Application Form</h3>
                                <form action="" method="POST">
                                    <?php
                                    include '../config.php';
                                    if (isset($_GET['id'])) {
                                        $id = $_GET['id'];
                                        $s = "select * from applicants where id='$id'";
                                        $result = $conn->query($s);
                                        while ($res = mysqli_fetch_assoc($result)) {
                                    ?>
                                            <div class="row mb-3">
                                                <label for="" class="col-sm-2 col-form-label">Full Name</label>
                                                <div class="col-sm-8">
                                                    <div class="row">
                                                        <div class="col-sm">
                                                            <input type="text" name="first_name" class="form-control text-capitalize" id="colFormLabel" placeholder="" value="<?= $res['firstname'] ?>">
                                                            <label for="" class="form-label">Firts Name</label>
                                                        </div>
                                                        <div class="col-sm">
                                                            <input type="text" name="last_name" class="form-control text-capitalize" id="colFormLabel" placeholder="" value="<?= $res['lastname'] ?>">
                                                            <label for="" class="form-label">Last Name</label>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row mb-3">
                                                <label for="" class="col-sm-2 col-form-label">Current Address</label>
                                                <div class="col-sm-8">
                                                    <div class="row">
                                                        <div class="col-sm">
                                                            <input type="text" name="address" class="form-control text-capitalize" value="<?= $res['address'] ?>">
                                                            <label for="" class="form-label">Street Address</label>
                                                        </div>
                                                    </div>

                                                    <div class="row">
                                                        <div class="col-sm">
                                                            <input type="text" name="city" class="form-control text-capitalize" id="colFormLabel" placeholder="" value="<?= $res['city'] ?>">
                                                            <label for="" class="form-label">City</label>
                                                        </div>
                                                        <div class="col-sm">
                                                            <input type="text" name="state" class="form-control text-capitalize" id="colFormLabel" placeholder="" value="<?= $res['state'] ?>">
                                                            <label for="" class="form-label">State</label>
                                                        </div>
                                                    </div>

                                                    <div class="row">
                                                        <div class="col-sm">
                                                            <input type="text" name="zip" class="form-control text-capitalize" id="colFormLabel" placeholder="" value="<?= $res['zip'] ?>">
                                                            <label for="" class="form-label">Postal / Zip Code</label>
                                                        </div>
                                                        <div class="col-sm">
                                                            <input type="text" name="country" class="form-control text-capitalize" id="colFormLabel" placeholder="" value="<?= $res['country'] ?>">
                                                            <label for="" class="form-label">Country</label>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="row mb-3">
                                                <label for="" class="col-sm-2 col-form-label">Email Address</label>
                                                <div class="col-sm-8">
                                                    <input type="email" name="email" class="form-control" value="<?= $res['email'] ?>">
                                                </div>
                                            </div>

                                            <div class="row mb-3">
                                                <label for="" class="col-sm-2 col-form-label">Phone Number</label>
                                                <div class="col-sm-8">
                                                    <div class="input-group">
                                                        <span class="input-group-text" id="basic-addon1">+91</span>
                                                        <input type="text" name="phone" class="form-control" placeholder="" aria-label="Username" aria-describedby="basic-addon1" value="<?= $res['phone'] ?>">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row mb-3">
                                                <label for="" class="col-sm-2 col-form-label">Applying for position</label>
                                                <div class="col-sm-8">
                                                    <input type="text" name="position" class="form-control text-capitalize" value="<?= $res['position'] ?>">
                                                </div>
                                            </div>
                                            <div class="d-grid col-2 mx-auto mb-3">
                                                <button type="submit" class="btn btn-primary mx-auto" name="update_applicants">Update</button>
                                            </div>
                                    <?php
                                        }
                                    }
                                    ?>
                                </form>
                            </div>
                        </div>
                        <!-- End Recent Sales -->
                    </div>
                </div>
                <!-- End Left side columns -->
                <!-- Right side columns -->
                <div class="col-lg-4">
                </div>
                <!-- End Right side columns -->
            </div>
        </section>

    </main><!-- End #main -->

    <!-- ======= Footer ======= -->
    <?php
    include 'footer.php';
    ?>
    <!-- End Footer -->
    <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

    <!-- Vendor JS Files -->
    <script src="assets/vendor/apexcharts/apexcharts.min.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="assets/vendor/chart.js/chart.min.js"></script>
    <script src="assets/vendor/echarts/echarts.min.js"></script>
    <script src="assets/vendor/quill/quill.min.js"></script>
    <script src="assets/vendor/simple-datatables/simple-datatables.js"></script>
    <script src="assets/vendor/tinymce/tinymce.min.js"></script>
    <script src="assets/vendor/php-email-form/validate.js"></script>

    <!-- Template Main JS File -->
    <script src="assets/js/main.js"></script>

</body>

</html>