<?php
function deleteapplicants()
{
    include '../config.php';
    $id = $_GET['id'];
    $query = "delete from applicants where id='$id'";
    $s = $conn->query($query);
    if ($s) {
        header('location:Dashboard.php');
        exit();
    } else {
        header('location:Dashboard.php');
        exit();
    }
}
deleteapplicants();
