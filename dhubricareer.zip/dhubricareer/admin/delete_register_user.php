<?php 
function delete_register_user(){
    include '../config.php';
    $id=$_GET['id'];
    $query="delete from user_registration where id='$id'";
    $s=$conn->query($query);
    if ($s) {
        header('location: registered_user.php');
        exit();
    }
    else {
        echo "something went wrong !";
        header('location: registered_user.php');
        exit();
    }
}
delete_register_user();