<?php 
function deletepost(){
    include '../config.php';
    $id=$_GET['id'];
    $query="delete from post where id='$id'";
    $s=$conn->query($query);
    if ($s) {
        header('location:post_view.php');
        exit();
    }
    else {
        header('location:post_view.php');
        exit();
    }
}
deletepost();



