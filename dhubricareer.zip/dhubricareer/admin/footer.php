<footer id="footer" class="footer">
    <div class="copyright">
      &copy; Copyright <strong><span>DhubriCareer</span></strong>. All Rights Reserved
    </div>
    <div class="credits">
      Designed by <a href="">DhubriCareer</a>
    </div>
  </footer>