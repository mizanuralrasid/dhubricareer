<footer id="footer" class="footer text-center text-center d-flex flex-column justify-content-center mx-auto">
    <div class="copyright">
      &copy; Copyright <strong><span>DhubriCareer</span></strong>. All Rights Reserved
    </div>
    <div class="credits">
      Designed by <a href="">DhubriCareer</a>
    </div>
  </footer>