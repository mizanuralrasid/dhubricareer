<?php
include 'header.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>view | Dhubri Career</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
</head>
<style>
  input {
    border: none;
  }

  input:focus {
    border: none;
  }
</style>

<body>
  <?php

  ?>
  <div class="container" >
    <?php
    require 'config.php';
    if (isset($_GET['slug_url'])) {
      $slug_url = $_GET['slug_url'];
      $s = "select * from post where slug_url='$slug_url'";
      $result = $conn->query($s);
      if (mysqli_num_rows($result) > 0) {
        foreach ($result as $row);
        // session_start();
        $_SESSION['position'] = $row['title'];
      }
    ?>
      <form action="" method="post" style="margin-left: 300px;" class="mt-3">
      <img src="<?php echo "../imgupload/" . $row['image']; ?>" class="img-fluid rounded-start" alt="..." style="height: 300px; widht:400px;">
        <h1 class="title"><?= $row['title'] ?></h1>
        <h3 class="description"><?= $row['description'] ?></h3>
        <button name=""><a href="../application.php?slug_url=<?= $row['slug_url']; ?>">apply</a></button>
      </form>
    <?php
    }
    ?>
  </div>

  <?php
  include 'footer.php';
  ?>

  <!-- Bootstrap JS -->
  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js" integrity="sha384-64xt8ztvG9q3H7aZ1qg5bm8xvKy5J1Uptvh6Uqj6BpzD6kI0bZudQzZoGxUxjzoB" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
</body>

</html>