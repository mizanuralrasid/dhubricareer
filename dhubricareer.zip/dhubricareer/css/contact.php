<style>
    .container {
	max-width: 600px;
	margin: auto;
	padding: 20px;
}

h1 {
	text-align: center;
	margin-bottom: 20px;
}

form {
	background-color: #f2f2f2;
	padding: 20px;
	border-radius: 5px;
}

label {
	display: block;
	margin-bottom: 10px;
	font-weight: bold;
}

input[type="text"],
input[type="email"],
textarea {
	width: 100%;
	padding: 10px;
	margin-bottom: 20px;
	border: none;
	border-radius: 3px;
}

textarea {
	height: 150px;
}

input[type="submit"] {
	background-color: #4CAF50;
	color: white;
	padding: 10px 20px;
	border: none;
	border-radius: 3px;
	cursor: pointer;
}

input[type="submit"]:hover {
	background-color: #3e8e41;
}

</style>