<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Dhubri Career</title>
  <link rel="stylesheet" href="style.css">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">



  <style>
    body {
      width: auto;
    }

    /* Extra small devices (portrait phones, less than 576px) */
    @media (max-width: 575.98px) {
      .card-group {
        display: block !important;
        grid-template-columns: auto auto !important;
      }

      .card-img-top {
        height: 30vh !important;
      }
    }

    /* Small devices (landscape phones, less than 768px) */
    @media (max-width: 767.98px) {}

    /* Medium devices (tablets, less than 992px) */
    @media (max-width: 991.98px) {
      .card-group {
        grid-template-columns: auto auto !important;
      }

    }

    /* Large devices (desktops, less than 1200px) */
    @media (max-width: 1199.98px) {}

    /* Extra large devices (large desktops) */
    /* No media query since the extra-large breakpoint has no upper bound on its width */
  </style>
</head>

<body>
  <!-- <nav class="navbar bg-body-tertiary">
    <div class="container-fluid">
      <a class="navbar-brand">Navbar</a>
      <form class="d-flex" role="search">
        <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
        <button class="btn btn-outline-success" type="submit">Search</button>
      </form>
    </div>
  </nav> -->
<?php
  include 'header.php';
?>
  <div class="container my-5 col-sm-10 mx-auto">
    <?php
    include 'config.php';
    $s = "select * from post";
    $result = $conn->query($s);
    while ($res = mysqli_fetch_array($result)) {
    ?>
      <div class="card mb-3" style="max-width: 740px;">
        <div class="row g-0">
          <div class="col-md-4">
            <img src="<?php echo "imgupload/" . $res['image']; ?>" class="img-fluid rounded-start" alt="...">
          </div>
          <div class="col-md-8">
            <div class="card-body">
              <h5 class="card-title"><?= $res['title']; ?></h5>
              <p class="card-text"><?= $res['description']; ?></p>
              <br>
              <a href="view.php/?slug_url=<?= $res['slug_url']; ?>">readmore</a>
              <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p>
            </div>
          </div>
        </div>
      </div>
    <?php
    }
    ?>


  </div>



  <!-- ---------------------------------contact------------------------------------- -->



  <?php
  include 'footer.php';
  ?>


  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
</body>

</html>