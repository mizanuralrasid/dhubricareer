<?php
require 'config.php';
session_start();
if (!isset($_SESSION['mobile']) || $_SESSION['loggedin'] !== true) {
    header("Location: registration.php");
    exit();
} 

if (isset($_POST['submit'])) {
    if (!empty(trim($_POST['first_name'])) && !empty(trim($_POST['last_name'])) && !empty(trim($_POST['address'])) && !empty(trim($_POST['city'])) && !empty(trim($_POST['state'])) && !empty(trim($_POST['zip'])) && !empty(trim($_POST['country'])) && !empty(trim($_POST['email'])) && !empty(trim($_POST['phone'])) && !empty(trim($_POST['position']))) {
        $first_name = $conn->real_escape_string($_POST['first_name']);
        $last_name = $conn->real_escape_string($_POST['last_name']);
        $address = $conn->real_escape_string($_POST['address']);
        $city = $conn->real_escape_string($_POST['city']);
        $state = $conn->real_escape_string($_POST['state']);
        $zip = $conn->real_escape_string($_POST['zip']);
        $country = $conn->real_escape_string($_POST['country']);
        $email = $conn->real_escape_string($_POST['email']);
        $phone = $conn->real_escape_string($_POST['phone']);
        $position = $conn->real_escape_string($_POST['position']);

        $q = "insert into applicants(firstname,lastname,address,city,state,zip,country,email,phone,position) values('$first_name','$last_name','$address','$city','$state','$zip','$country','$email','$phone','$position')";

        $result = $conn->query($q);

        if ($result) {
            header("location: index.php");
            exit();
        } else {
            echo "somtthing wrong";
        }
    }
}


?>
<!DOCTYPE html>
<html>

<head>
    <title>Job Application Form</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
</head>
<style>
    #profile {
        height: 35px;
        width: 35px;
        background: gray;
        border-radius: 50%;
        border: 2px solid black;
        position: absolute;
    }
</style>

<body>
    <nav class="navbar bg-body-tertiary">
        <div class="container-fluid">
            <a class="navbar-brand">Navbar</a>
            <form class="d-flex" role="search">
                <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
                <button class="btn btn-outline-success" type="submit">Search</button>
            </form>
        </div>
    </nav>
    <nav class="navbar navbar-expand-lg bg-body-tertiary">
        <div class="container-fluid">
            <!-- <a class="navbar-brand" href="#">Navbar</a> -->
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavDropdown">
                <ul class="navbar-nav">
                    <li class="nav-item mx-5">
                        <a class="nav-link active" aria-current="page" href="#">Home</a>
                    </li>
                    <li class="nav-item mx-5">
                        <a class="nav-link" href="#">Features</a>
                    </li>
                    <li class="nav-item mx-5">
                        <a class="nav-link" href="#">Pricing</a>
                    </li>
                    <li class="nav-item mx-5">
                        <a class="nav-link" href="#">Pricing</a>
                    </li>
                    <li class="nav-item mx-5">
                        <a class="nav-link" href="#">Pricing</a>
                    </li>
                    <li class="nav-item mx-5 dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            Dropdown link
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="#">Action</a></li>
                            <li><a class="dropdown-item" href="#">Another action</a></li>
                            <li><a class="dropdown-item" href="#">Something else here</a></li>
                        </ul>
                    </li>
                    <?php
                    if (isset($_SESSION['mobile']) || $_SESSION['loggedin'] == true) {
                    ?>
                        <li class="nav-item mx-5 dropdown">
                            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false" id="profile">
                            </a>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item"><?php echo  $_SESSION['mobile']; ?></a></li>
                                <li><a class="dropdown-item" href="#">profile</a></li>
                                <li><a class="dropdown-item" href="logout.php">logout</a></li>
                            </ul>
                        </li>
                    <?php
                    }
                    ?>
                </ul>
            </div>
        </div>
    </nav>


    <div class="container mt-5">
        <h3 class="fw-bolder mx-5 mb-3">Job Application Form</h3>
        <form action="" method="POST">
            <div class="row mb-3">
                <label for="" class="col-sm-2 col-form-label">Email</label>
                <div class="col-sm-8">
                    <div class="row">
                        <div class="col-sm">
                            <input type="text" name="first_name" class="form-control" id="colFormLabel" placeholder="">
                            <label for="" class="form-label">Firts Name</label>
                        </div>
                        <div class="col-sm">
                            <input type="text" name="last_name" class="form-control" id="colFormLabel" placeholder="">
                            <label for="" class="form-label">Last Name</label>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row mb-3">
                <label for="" class="col-sm-2 col-form-label">Current Address</label>
                <div class="col-sm-8">
                    <div class="row">
                        <div class="col-sm">
                            <input type="text" name="address" class="form-control">
                            <label for="" class="form-label">Street Address</label>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-sm">
                            <input type="text" name="city" class="form-control" id="colFormLabel" placeholder="">
                            <label for="" class="form-label">City</label>
                        </div>
                        <div class="col-sm">
                            <input type="text" name="state" class="form-control" id="colFormLabel" placeholder="">
                            <label for="" class="form-label">State</label>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-sm">
                            <input type="text" name="zip" class="form-control" id="colFormLabel" placeholder="">
                            <label for="" class="form-label">Postal / Zip Code</label>
                        </div>
                        <div class="col-sm">
                            <input type="text" name="country" class="form-control" id="colFormLabel" placeholder="">
                            <label for="" class="form-label">Country</label>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row mb-3">
                <label for="" class="col-sm-2 col-form-label">Email Address</label>
                <div class="col-sm-8">
                    <input type="email" name="email" class="form-control">
                </div>
            </div>

            <div class="row mb-3">
                <label for="" class="col-sm-2 col-form-label">Phone Number</label>
                <div class="col-sm-8">
                    <div class="input-group">
                        <span class="input-group-text" id="basic-addon1">+91</span>
                        <input type="text" name="phone" class="form-control" placeholder="" aria-label="Username" aria-describedby="basic-addon1">
                    </div>
                </div>
            </div>
            <div class="row mb-3">
                <label for="" class="col-sm-2 col-form-label">Applying for position</label>
                <div class="col-sm-8">
                    <input type="text" name="position" class="form-control" value="<?= $_SESSION['position']; ?>" readonly>
                </div>
            </div>
            <div class="d-grid col-2 mx-auto mb-3">
            <button type="submit" class="btn btn-primary mx-auto" name="submit">Submit</button>
            </div>
        </form>

        <?php
            include 'footer.php';
        ?>
    </div>
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
</body>

</html>