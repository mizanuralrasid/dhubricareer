<?php
function admin_sign_up()
{
    include '../config.php';
    if (isset($_POST['new_admin'])) {
        if (!empty(trim($_POST['name'])) && !empty(trim($_POST['email'])) && !empty(trim($_POST['username'])) && !empty(trim($_POST['password']))) {
            $name = $conn->real_escape_string($_POST['name']);
            $email = $conn->real_escape_string($_POST['email']);
            $username = $conn->real_escape_string($_POST['username']);
            $password = $conn->real_escape_string($_POST['password']);

            // convert password into hash password
            // $pass_hash = password_hash($password, PASSWORD_BCRYPT);

            // SELECT THE USERNAME FORM THE EXISTING TABLE AND VERIFY THE USER INFORMATION IF THE INFORMATION IS ALREADY USED LET THEM KNOW MESSAGE THIS USERNAME IS ALREADY TAKEN

            $select = "select * from admin where username = '$username'";

            // execute the query
            $select_Query = $conn->query($select);

            // verify the information is already taken or not
            $nums = mysqli_num_rows($select_Query);

            if ($nums > 0) {
?>
                <script>
                    alert("This username is already taken try another");
                </script>
            <?php
            } else {
                $insert = "insert into admin(name,email,username,password) values('$name','$email','$username','$password')";

                $query = $conn->query($insert);
                if ($query) {
                    $_SESSION['message'] = "Register Successfully now you can login";
                    header('location:../admin/index.php');
                    exit(0);
                }
            }
        } else {
            ?>
            <script>
                alert("All fields are required");
            </script>
        <?php
        }
    } else {
        ?>
        <script>
            alert("Something went wrong !");
        </script>
<?php
    }
}

admin_sign_up();