<?php
function addpost()
{
    session_start();
    include '../config.php';
    if (isset($_POST['add_post'])) {
        $title = $_POST['title'];
        $slug_url = strtolower($title);
        $slug_url = '/' . str_replace(' ', '-', $title);
        $content = $_POST['content'];
        $meta_title = $_POST['meta_title'];
        $meta_description = $_POST['meta_description'];
        $meta_keyword = $_POST['meta_keyword'];
        $files = $_FILES['file'];


        $filename = $files['name'];
        $fileerror = $files['error'];
        $filetmp = $files['tmp_name'];

        $fileext = explode('.', $filename);
        $filecheck = strtolower(end($fileext));
        $fileextstored = array('png', 'jpg', 'jpeg');
        if (in_array($filecheck, $fileextstored)) {
            $destinationfile = '../imgupload/' . $filename;
            move_uploaded_file($filetmp, $destinationfile);

            $sql = "insert into post(title,slug_url,description,meta_title,meta_description,meta_keyword,image) values('$title','$slug_url','$content','$meta_title','$meta_description','$meta_keyword','$destinationfile')";
            $query = mysqli_query($conn, $sql);
            $_SESSION['message'] = "Post Add Successfully";
            header('location:../admin/Dashboard.php');
            exit(0);
        } else {
            $_SESSION['message'] = "Post Failed Upload";
            header('location:../admin/Dashboard.php');
        }
    }
}
addpost();
