<?php
include '../config.php';
session_start();
if (isset($_POST['update_post'])) {
    $id = $_GET['id'];
    $title = $_POST['title'];
    $slug_url = strtolower($title);
    $slug_url = '/' . str_replace(' ', '-', $title);
    $content = $_POST['content'];
    $meta_title = $_POST['meta_title'];
    $meta_description = $_POST['meta_description'];
    $meta_keyword = $_POST['meta_keyword'];
echo $id;
    $iq = "update post set id=$id,title='$title',slug_url='$slug_url',description='$content',meta_title='$meta_title',meta_description='$meta_description',meta_keyword='$meta_keyword' where id=$id";
    $q = $conn->query($iq);
    header('location:../admin/post_view.php');
} else {
    echo "Soomething went wrong";
}
?>
