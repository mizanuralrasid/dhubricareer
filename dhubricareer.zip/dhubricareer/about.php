<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link rel="stylesheet" href="style.css">
    <?php
    include 'css/contact.php';
    ?>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">



    <style>
        body {
            width: auto;
        }

        /* .card {
      height: 60vh !important;
    }

    .card-body {
      height: 70% !important;
      overflow: hidden !important;
      text-overflow: ellipsis;
    }

    .card-body p {
      height: 48% !important;
      overflow: hidden !important;
      text-overflow: ellipsis;
    }

    .card-img-top {
      height: 50% !important;
    } */


        /* Extra small devices (portrait phones, less than 576px) */
        @media (max-width: 575.98px) {
            .card-group {
                display: block !important;
                grid-template-columns: auto auto !important;
            }

            .card-img-top {
                height: 30vh !important;
            }
        }

        /* Small devices (landscape phones, less than 768px) */
        @media (max-width: 767.98px) {}

        /* Medium devices (tablets, less than 992px) */
        @media (max-width: 991.98px) {
            .card-group {
                grid-template-columns: auto auto !important;
            }

        }

        /* Large devices (desktops, less than 1200px) */
        @media (max-width: 1199.98px) {}

        /* Extra large devices (large desktops) */
        /* No media query since the extra-large breakpoint has no upper bound on its width */
    </style>
</head>

<body>
    <nav class="navbar bg-body-tertiary">
        <div class="container-fluid">
            <a class="navbar-brand">Navbar</a>
            <form class="d-flex" role="search">
                <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
                <button class="btn btn-outline-success" type="submit">Search</button>
            </form>
        </div>
    </nav>



    <nav class="navbar navbar-expand-lg bg-body-tertiary">
        <div class="container-fluid">
            <!-- <a class="navbar-brand" href="#">Navbar</a> -->
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavDropdown">
                <ul class="navbar-nav">
                    <li class="nav-item mx-5">
                        <a class="nav-link active" aria-current="page" href="#">Home</a>
                    </li>
                    <li class="nav-item mx-5">
                        <a class="nav-link" href="#">Features</a>
                    </li>
                    <li class="nav-item mx-5">
                        <a class="nav-link" href="#">Pricing</a>
                    </li>
                    <li class="nav-item mx-5">
                        <a class="nav-link" href="#">Pricing</a>
                    </li>
                    <li class="nav-item mx-5">
                        <a class="nav-link" href="#">Pricing</a>
                    </li>
                    <li class="nav-item mx-5 dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            Dropdown link
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="#">Action</a></li>
                            <li><a class="dropdown-item" href="#">Another action</a></li>
                            <li><a class="dropdown-item" href="#">Something else here</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>






    <div class="container bg-secondary">
        <h1>About Us</h1>
        <p>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Eos, repudiandae! Explicabo est cum qui quos rerum quia eius culpa adipisci repellat, voluptas aspernatur aut porro minima corporis in dolor quibusdam nisi illo veniam iste quidem? Ducimus vero modi atque veniam aspernatur beatae et? Reiciendis voluptatem obcaecati est mollitia. Adipisci quaerat consectetur, ipsum laudantium cum amet provident ratione dolorem? Labore illum ratione, tempora iste dicta eos in repudiandae ea necessitatibus nulla ab quos, repellendus molestias. Iure aliquam ratione quis. Voluptate, iste beatae quas animi facilis natus voluptatibus nam obcaecati deserunt quis cumque, ratione nostrum nulla voluptatum eveniet recusandae officiis! Sed assumenda saepe repudiandae perspiciatis, excepturi quod, ducimus neque cumque numquam error ratione aut recusandae labore cum omnis dolores, accusantium nam magnam doloremque in necessitatibus. Consequuntur, ullam expedita? Laudantium quod facilis aut, optio nostrum, soluta aspernatur obcaecati labore veniam dolores doloremque quae dolorem enim ipsum? Incidunt, at eaque odit exercitationem dicta obcaecati harum animi ducimus quis ipsam sunt facilis deleniti debitis architecto nemo ipsum quos unde sed qui, voluptatum iure maiores praesentium eum voluptatibus! Voluptate soluta rem quas ab eveniet inventore et nihil cupiditate esse architecto expedita minima at quo commodi id provident minus accusamus sunt recusandae, quasi eum perferendis nisi facilis. Assumenda, ad dicta! Rem praesentium accusantium natus explicabo rerum veniam possimus modi facilis cumque porro dicta ut, quisquam tenetur corrupti necessitatibus officia non nesciunt sunt deleniti quas omnis reiciendis iste. Dicta ullam autem quod quibusdam fuga, rerum totam nesciunt obcaecati adipisci optio nihil voluptatum ipsum. Alias veritatis quod placeat ipsa dolores iure, illum tempore maiores laudantium eveniet minima minus perferendis. Numquam autem totam natus fugit impedit dolorem eaque reiciendis sit expedita ex, consectetur illum consequuntur iste ipsa molestias amet eius. Consequuntur, quae fugiat quod, laborum esse repellendus in autem iste, aspernatur tempore perspiciatis blanditiis. Maiores delectus in aspernatur iusto placeat quasi natus sapiente, quis omnis architecto vitae neque obcaecati nam consequatur veniam hic voluptas maxime vel vero eligendi facilis fugiat. Libero harum culpa veritatis itaque doloremque, fugiat ea ipsum architecto, alias quaerat vel explicabo nemo cupiditate maxime impedit nam voluptates sequi sunt omnis est dolores saepe corporis. Architecto debitis recusandae porro voluptas neque. Quidem consequatur ab cumque illum? Aperiam aspernatur libero itaque veritatis sapiente vel modi, nesciunt, culpa rem aut cum obcaecati dolor cumque accusantium, cupiditate minima numquam amet quo saepe recusandae architecto. Incidunt accusamus natus nam vel mollitia delectus. Accusantium at ad aliquid, nihil eum nesciunt odio voluptas cum cupiditate tempora quia nemo modi exercitationem eius deleniti officia eos fugit natus voluptates sunt laborum perspiciatis odit. Ullam autem tempore delectus illo fugiat! Quibusdam culpa aspernatur ducimus sed quasi rem exercitationem officia? Esse, sit? Nostrum a velit vero dolorum veniam mollitia recusandae cupiditate consequatur, possimus labore et, eaque sequi nobis doloribus minima dicta aliquam, dignissimos ex. Totam nesciunt commodi esse placeat excepturi dolore dolorem, libero voluptatem ipsum voluptatibus illum nisi! Sunt nemo temporibus eos quis fugit officiis laudantium, expedita reiciendis assumenda? Enim iste veritatis qui dignissimos, laboriosam ea nisi cum dolores fuga temporibus officia nesciunt quas molestias ipsam ex labore porro, doloribus distinctio delectus quam dolore illo amet quasi. Perspiciatis provident ab mollitia delectus veniam fugiat porro, animi facere magni vel est odit laborum cum nemo distinctio nostrum nam? Ipsum repellat culpa fugit libero? Cumque, repellendus accusantium labore placeat ipsa praesentium officiis reiciendis? Ipsam reprehenderit, necessitatibus aspernatur cum sunt, voluptate harum iure doloribus, dolores impedit officiis repellendus a ipsa magni iste. Aperiam nobis delectus eaque voluptate necessitatibus eos harum qui atque incidunt ipsam nulla velit quasi fuga quaerat ullam animi provident voluptatibus, sit omnis cumque reiciendis perferendis deleniti non voluptates. Reprehenderit omnis magnam modi fuga voluptates ad porro animi atque quod amet iure voluptatum, culpa illo obcaecati possimus! Esse animi magni eveniet explicabo est, optio, libero impedit dolorum assumenda, placeat facilis perferendis quasi qui temporibus unde magnam tempora. Dolorum placeat accusantium minus amet ad facilis odit nesciunt modi, deleniti vero. Voluptas corrupti illum ut, neque pariatur omnis distinctio quod inventore enim nemo facere minima esse architecto porro asperiores odio quas quis dolorem, quam, tenetur autem quia facilis. Aliquam perferendis corrupti dolorum incidunt optio molestias quam facilis nemo voluptatem voluptates. Tempora obcaecati expedita provident? Esse voluptas itaque laborum aliquam quibusdam. Recusandae doloremque iusto eos unde, repudiandae, fuga dolore quod voluptatibus quibusdam debitis optio. Illo perspiciatis necessitatibus doloremque, nesciunt maxime, accusamus quasi quam, obcaecati quae ipsum esse consectetur placeat ipsam beatae unde voluptatibus asperiores quos expedita temporibus iusto sed mollitia! Asperiores eaque nesciunt quo magni incidunt odio praesentium nihil veritatis, a error officia obcaecati quam totam porro facere magnam, ut sunt! Deserunt, consequuntur sapiente! Nihil voluptate, quas tenetur autem ea a dicta cum porro distinctio dolore delectus atque provident dolor aliquid deserunt aliquam adipisci omnis, suscipit consequuntur quidem? Assumenda suscipit eius repellendus odit totam, modi dolore similique? Repudiandae, vel labore reprehenderit, necessitatibus at quam consequuntur dolorum blanditiis libero asperiores debitis omnis fuga perspiciatis enim sapiente quo magnam quisquam expedita laboriosam dolorem accusantium, facere sunt explicabo! Nam praesentium distinctio magnam voluptatum delectus est unde error perspiciatis optio illum architecto suscipit impedit quasi, earum quaerat dolorem eum, tenetur accusantium excepturi nisi. Quia dolor dicta libero molestiae, laborum porro reprehenderit et accusantium nisi unde excepturi ab repellat saepe architecto adipisci recusandae animi voluptatum explicabo amet odio quisquam? Maxime minus neque repellendus sit ullam recusandae totam rem dignissimos! Minima eveniet sapiente aliquam sint culpa adipisci officiis quo incidunt unde tempore distinctio sed repellat quia vel itaque magni voluptate, nostrum velit iusto perspiciatis. Labore a pariatur quibusdam neque rerum, ullam dolores! Pariatur accusantium libero totam temporibus nobis commodi delectus. Magnam cumque fugiat quae? Illo cupiditate minima sunt qui odio delectus, architecto recusandae officiis similique, reiciendis voluptas porro autem maxime explicabo aperiam! Officiis, dolorum impedit? Minus repudiandae aliquid repellendus. Est optio ex nesciunt illum. Ratione a omnis eaque expedita esse? Aperiam magni tenetur maiores animi aspernatur quo libero aliquam ad! Rem, repellendus reprehenderit eligendi deleniti expedita qui sequi explicabo, ipsum enim, voluptatibus sapiente blanditiis? Dolorum eveniet deserunt distinctio fugit tempora praesentium illum quos? Quam a itaque harum officia odit. Voluptatum officia illo nemo molestiae voluptates numquam quisquam repudiandae beatae, veniam est dolores accusantium quae quibusdam sequi expedita delectus odit corrupti laborum magnam inventore! Praesentium omnis sapiente qui. Quia quam mollitia officiis deleniti, quas eaque, repudiandae, dicta nam inventore sequi quaerat cupiditate veritatis nesciunt corporis modi sapiente. Dolorem recusandae assumenda nobis molestias, similique praesentium? Unde provident eaque ipsa molestiae excepturi modi neque voluptas sint velit dolore facere libero aspernatur eum culpa possimus obcaecati alias labore, adipisci et iusto natus quia veritatis non? Rerum adipisci itaque provident. Odio expedita sit voluptas dolore omnis consequatur sint, incidunt tempore laborum. Commodi officia sapiente explicabo maxime harum delectus? Nostrum error corrupti deserunt perferendis dignissimos. Provident labore deleniti cupiditate. Possimus alias a amet nisi, mollitia consequatur autem deserunt odit architecto voluptatem labore earum fuga saepe vitae suscipit illum incidunt, veniam itaque ad beatae voluptatum. Eligendi dignissimos vel fugiat itaque ex nemo accusamus in sint deserunt id eveniet consequuntur tempore sit quasi qui, repellendus aliquam ducimus quia error. Est itaque tenetur cumque eos at quibusdam quas ipsa officia, nisi maxime accusamus vitae optio odit eum voluptatum dignissimos molestias iure asperiores quae fugiat dolorem obcaecati! Harum nisi nobis et officiis nulla aliquam, dolores nemo debitis recusandae culpa facilis natus odit quos incidunt assumenda porro provident cupiditate.
        </p>
    </div>



    <!-- ---------------------------------contact------------------------------------- -->



    <?php
    include 'footer.php';
    ?>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
</body>

</html>